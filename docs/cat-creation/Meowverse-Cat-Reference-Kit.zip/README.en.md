# Bring your own cat · Meowverse user kit

[简体中文](README.md) | English

This minimal user kit was updated on November 20, 2026 (reference kit 2.1: one image per message). It is neither the app nor a finished cat model pack.

**Latest instructions:** https://github.com/Fengyee/meowverse-core/blob/main/docs/cat-creation/README.en.md

## Input materials

- **POSE_GUIDE.png:** the gray model from all eight cameras on one sheet, for message 1.
- **guides/:** eight single-view gray guides, one attached to each of messages 2–9.
- **prompts/:** ten prompts. Copy each one in file-name order and paste it; no TXT attachment is needed.

Real photographs define your cat's identity, proportions and markings. The gray guide controls only pose, camera and framing. Where possible, provide a front face, both sides and back, using photos you have the right to provide without human faces, addresses, identity documents or other private information.

**Do not send real source photographs to the Meowverse preparation request.** Photos you choose to upload to ChatGPT are sent to that third-party service and handled under your account settings and its policies. This is not on-device generation.

## Generate, check and submit

In one new conversation, send ten messages with one image each, waiting for each result before the next:

| Message | Attach | Paste |
| --- | --- | --- |
| 1 | `POSE_GUIDE.png` and all your cat photographs | `prompts/00_SHEET.txt` |
| 2–9 | the guide with the same name from `guides/` | `prompts/01_FRONT.txt` … `08_HEAD_RIGHT.txt` |
| 10 | nothing | `prompts/09_PACKAGE.txt` |

Message 1 makes an eight-panel sheet that settles the cat. Messages 2–9 make the front, left-facing, right-facing, back and top-down full-body views and the front, left-facing and right-facing head close-ups, one at a time. Message 10 packages them as `cat_views.zip`. If a view is wrong, send that message again with its guide, preceded by one sentence saying what is wrong (for example “the black spot on the nose is missing”). Compare each view with the guide of the same name: camera, direction, size and position should match.

Check face shape, markings, proportions, paws and tail. Full-body references should show a neutral standing cat with four paws planted and the tail extending straight backward. Visible paws should stay inside the frame; far-side legs may be naturally hidden in exact profiles, without moving them to expose all four. Do not mirror the markings to invent the other side. The ZIP from message 10 already names each view and can be submitted as is; if packaging fails, download each full-resolution image. Do not submit screenshots of the conversation.

**Submit only selected generated references**, not source photos, chat transcripts, conversation links or account credentials. Prefer one cat per issue:

https://github.com/Fengyee/meowverse-core/issues/new?template=03-cat-reference.yml

Sign in to GitHub, enter a public cat nickname, attach generated images or a ZIP and wait for uploads to finish. Direct images are limited to 10 MB each. A ZIP under 20 MB is convenient; GitHub's ZIP limit is 25 MB. Include only generated reference images in it.

**Issues, comments and attachments are public and downloadable. Files are sent to GitHub as soon as you attach them.** Check images, filenames and metadata first. Generated images are not guaranteed anonymous. Do not upload anything you do not want to make public.

## Import a finished pack

Review and preparation are manual, with no guaranteed acceptance, completion or delivery date. If a pack can be completed, follow the issue's delivery arrangements to obtain the `.meowcat` file. Public release of the finished pack requires separate agreement.

In a compatible app build, open Room → More (…) → Settings → Cat models → Import Cat Model. Reference PNGs and ZIPs are not finished `.meowcat` packs.

Submissions allow work on this reference review and cat-pack request; they do not automatically license built-in app inclusion, training or asset-pack distribution. Wider use needs separate agreement.

## Other included files

- **cat-creation-flow-bella.png:** a shareable Chinese workflow poster. Its QR opens the full guide. This illustration is not the pose template or an app screenshot.
- **cat-creation-flow-bella-en.png:** the English edition of the workflow poster, with a QR that opens the English guide.
- **ATTRIBUTION.md / TEMPLATE_ATTRIBUTION.md:** sources, Fripouille author credit and CC BY 4.0 attribution. Keep them with the template; the code license does not automatically cover the images.

Both posters show the November 15, 2026 one-message version of the workflow; follow the steps in this README.

This kit excludes Blender/GLB sources, camera projects, production scripts, private source photos and production app artwork sources.
