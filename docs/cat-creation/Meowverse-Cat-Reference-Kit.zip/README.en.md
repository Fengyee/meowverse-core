# Bring your own cat · Meowverse user kit

[简体中文](README.md) | English

This minimal user kit was prepared on November 15, 2026. Its pose guide and prompt come from reference kit 1.1. It is neither the app nor a finished cat model pack.

**Latest instructions:** https://github.com/Fengyee/meowverse-core/blob/main/docs/cat-creation/README.en.md

## Two input materials

- **POSE_GUIDE.png:** add this gray pose guide alongside photographs of your cat in your own ChatGPT message box, but do not send yet.
- **GENERATE_ALL_VIEWS.txt:** open it, copy the entire prompt and paste it into that same message. Send the photos, guide and prompt together once. No per-view rewriting or TXT attachment is needed.

Real photographs define your cat's identity, proportions and markings. The gray guide controls only pose, camera and framing. Where possible, provide a front face, both sides and back, using photos you have the right to provide without human faces, addresses, identity documents or other private information.

**Do not send real source photographs to the Meowverse preparation request.** Photos you choose to upload to ChatGPT are sent to that third-party service and handled under your account settings and its policies. This is not on-device generation.

## Generate, check and submit

The complete request asks for eight separate, high-resolution square views: front, left-facing profile, right-facing profile, back and top-down full-body views, plus front, left-facing and right-facing head close-ups. Output may omit a view or combine views into a contact sheet. One request does not guarantee eight separate files; ask for corrections in the same conversation before selecting the results. A contact sheet can be reviewed initially, but separate full-resolution views may still be needed for modeling.

Check face shape, markings, proportions, paws and tail. Full-body references should show a neutral standing cat with four paws planted and the tail extending straight backward. Visible paws should stay inside the frame; far-side legs may be naturally hidden in exact profiles, without moving them to expose all four. Do not mirror the markings to invent the other side. Download the selected generated images themselves, rather than screenshots of the conversation.

**Submit only selected generated references**, not source photos, chat transcripts, conversation links or account credentials. Prefer one cat per issue:

https://github.com/Fengyee/meowverse-core/issues/new?template=03-cat-reference.yml

Sign in to GitHub, enter a public cat nickname, attach generated images or a ZIP and wait for uploads to finish. Direct images are limited to 10 MB each. A ZIP under 20 MB is convenient; GitHub's ZIP limit is 25 MB. Include only generated reference images in it.

**Issues, comments and attachments are public and downloadable. Files are sent to GitHub as soon as you attach them.** Check images, filenames and metadata first. Generated images are not guaranteed anonymous. Do not upload anything you do not want to make public.

## Import a finished pack

Review and preparation are manual, with no guaranteed acceptance, completion or delivery date. If a pack can be completed, follow the issue's delivery arrangements to obtain the `.meowcat` file. Public release of the finished pack requires separate agreement.

In a compatible app build, open Room → More (…) → Settings → Cat models → Import Cat Model. Reference PNGs and ZIPs are not finished `.meowcat` packs.

Submissions allow work on this reference review and cat-pack request; they do not automatically license built-in app inclusion, training or asset-pack distribution. Wider use needs separate agreement.

## Other included files

- **cat-creation-flow-bella.png:** a shareable Chinese workflow poster. Its QR opens the full guide. This illustration is not the pose template or an app screenshot.
- **cat-creation-flow-bella-en.png:** the English edition of the workflow poster, with a QR that opens the English guide.
- **ATTRIBUTION.md / TEMPLATE_ATTRIBUTION.md:** sources, Fripouille author credit and CC BY 4.0 attribution. Keep them with the template; the code license does not automatically cover the images.

This kit excludes Blender/GLB sources, individual gray-model view images, camera projects, production scripts, private source photos and production app artwork sources.
